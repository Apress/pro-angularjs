// var client = require('../internal-client');

// TODO: Write tests. Internal client is very dependent on Context, 
// and by extension, the http request, and is not very easy to test.