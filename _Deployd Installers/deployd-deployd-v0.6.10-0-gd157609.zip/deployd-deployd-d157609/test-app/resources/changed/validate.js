if(this.name === 'first name change') {
    if(changed('name')) {
        this.name = 'saw first name changed previous ' + previous.name;
    }
}