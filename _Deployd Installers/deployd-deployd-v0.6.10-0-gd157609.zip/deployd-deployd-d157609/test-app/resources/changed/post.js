if(!(changed('name') && previous.name === undefined)) {
    cancel('changed and/or previous are broken...');
}